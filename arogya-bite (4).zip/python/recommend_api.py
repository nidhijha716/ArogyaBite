import sys
import json
import pandas as pd
import pickle
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

def preprocess_ingredients(ingredient_list):
    return [ingredient.strip().lower() for ingredient in ingredient_list]

def average_vector(ingredients, model):
    vectors = [model.wv[word] for word in ingredients if word in model.wv]
    return np.mean(vectors, axis=0) if vectors else np.zeros(model.vector_size)

def recommend_recipes(allergies, preferences, df, word2vec_model):
    allergies = preprocess_ingredients(allergies)
    preferences = preprocess_ingredients(preferences)

    # Generate preference vector
    preference_vector = average_vector(preferences, word2vec_model)

    # Compute similarities for all recipes
    recipe_vectors = []
    for ingredients in df['Ingredients_name']:
        if not isinstance(ingredients, str):  # Handle missing or non-string values
            recipe_vectors.append(np.zeros(word2vec_model.vector_size))
            continue
        ingredient_list = [i.strip().lower() for i in ingredients.split(',')]
        vec = average_vector(ingredient_list, word2vec_model)
        recipe_vectors.append(vec)

    similarity_scores = cosine_similarity([preference_vector], recipe_vectors)[0]

    df['similarity_score'] = similarity_scores

    # Filter out recipes that contain allergens
    def contains_allergen(ingredients):
        if not isinstance(ingredients, str):
            return False
        return any(allergen in ingredients.lower() for allergen in allergies)

    filtered_df = df[~df['Ingredients_name'].apply(contains_allergen)]

    top_recommendations = filtered_df.sort_values(by='similarity_score', ascending=False).head(5)

    # Convert to list of dictionaries for JSON response
    result = []
    for _, row in top_recommendations.iterrows():
        result.append({
            'id': int(row.name) if isinstance(row.name, (int, float)) else 0,
            'name': row['Name'],
            'ingredients': row['Ingredients_name'],
            'similarity_score': float(row['similarity_score'])
        })

    return result

if __name__ == "__main__":
    try:
        # Get command line arguments
        allergies_json = sys.argv[1]
        preferences_json = sys.argv[2]
        
        # Parse JSON arguments
        allergies = json.loads(allergies_json)
        preferences = json.loads(preferences_json)
        
        # Load models and data
        model_path = 'python/models/word2vec_model.pkl'
        data_path = 'python/data/Food_Recipes_Cleaned.csv'
        
        with open(model_path, 'rb') as f:
            word2vec_model = pickle.load(f)
        
        df = pd.read_csv(data_path)
        
        # Get recommendations
        recommendations = recommend_recipes(allergies, preferences, df, word2vec_model)
        
        # Print JSON result to stdout
        print(json.dumps(recommendations))
        
    except Exception as e:
        # Print error to stderr
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)
