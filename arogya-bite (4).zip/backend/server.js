const express = require("express")
const cors = require("cors")
const { spawn } = require("child_process")
const path = require("path")
const fs = require("fs")

const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(express.json())

// Helper function to run Python script
async function runPythonScript(allergies, preferences) {
  return new Promise((resolve, reject) => {
    // Path to the Python script
    const scriptPath = path.join(__dirname, "recommend_api.py")

    // Check if the script exists
    if (!fs.existsSync(scriptPath)) {
      reject(new Error(`Python script not found at ${scriptPath}`))
      return
    }

    // Spawn Python process
    const pythonProcess = spawn("python", [scriptPath, JSON.stringify(allergies), JSON.stringify(preferences)])

    let result = ""
    let errorOutput = ""

    // Collect data from script
    pythonProcess.stdout.on("data", (data) => {
      result += data.toString()
    })

    pythonProcess.stderr.on("data", (data) => {
      errorOutput += data.toString()
    })

    // Handle process completion
    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`Python script exited with code ${code}: ${errorOutput}`))
        return
      }

      try {
        const parsedResult = JSON.parse(result)
        resolve(parsedResult)
      } catch (error) {
        reject(new Error(`Failed to parse Python script output: ${result}`))
      }
    })
  })
}

// Recipe recommendation endpoint
app.post("/api/recommend", async (req, res) => {
  try {
    const { allergies = [], preferences = [] } = req.body

    // Validate input
    if (!preferences.length) {
      return res.status(400).json({ error: "Please provide at least one preferred ingredient" })
    }

    // Run Python script
    const recommendations = await runPythonScript(allergies, preferences)

    return res.json({ recommendations })
  } catch (error) {
    console.error("Error in recommendation API:", error)
    return res.status(500).json({ error: error.message || "Internal server error" })
  }
})

// Serve static assets in production
if (process.env.NODE_ENV === "production") {
  // Set static folder
  app.use(express.static(path.join(__dirname, "../frontend/build")))

  app.get("*", (req, res) => {
    res.sendFile(path.resolve(__dirname, "../frontend", "build", "index.html"))
  })
}

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
