"use client"

import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { useEffect } from "react"
import Navbar from "./components/Navbar"
import Footer from "./components/Footer"
import ScrollToTop from "./components/ScrollToTop"
import Home from "./pages/Home"
import UploadImage from "./pages/UploadImage"
import RiskReport from "./pages/RiskReport"
import AboutUs from "./pages/AboutUs"
import Contact from "./pages/Contact"
import NotFound from "./pages/NotFound"
import RecipeRecommendation from "./pages/RecipeRecommendation"

function App() {
  // Set page title
  useEffect(() => {
    document.title = "ArogyaBite: Scan, Detect, Eat Safe!"
  }, [])

  return (
    <Router>
      <ScrollToTop />
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/upload" element={<UploadImage />} />
            <Route path="/report/:id" element={<RiskReport />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/recipes" element={<RecipeRecommendation />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App
