// Base API URL - change this to your actual backend URL
const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000"

// Recipe recommendation API
export const getRecipeRecommendations = async (allergies, preferences) => {
  try {
    const response = await fetch(`${API_URL}/api/recommend`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        allergies,
        preferences,
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to get recommendations")
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching recipe recommendations:", error)
    throw error
  }
}

// Export other API functions here
