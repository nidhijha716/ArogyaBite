"use client"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { ChevronRight, AlertTriangle, Loader2 } from "lucide-react"
import Button from "../components/Button"
import SectionHeading from "../components/SectionHeading"

const RecipeRecommendations = () => {
  const [allergies, setAllergies] = useState("")
  const [preferences, setPreferences] = useState("")
  const [recommendations, setRecommendations] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("http://localhost:5000/api/recommend", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          allergies: allergies.split(",").map((item) => item.trim()),
          preferences: preferences.split(",").map((item) => item.trim()),
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to get recommendations")
      }

      const data = await response.json()
      setRecommendations(data.recommendations)
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen pt-20 pb-12 bg-gray-50">
      <div className="container-custom">
        <SectionHeading
          title="Recipe Recommendations"
          subtitle="Get personalized recipe recommendations based on your allergies and preferences"
          centered={true}
        />

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-md p-6 md:p-8 mb-8">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="allergies" className="block text-sm font-medium text-gray-700 mb-1">
                    Allergies
                  </label>
                  <textarea
                    id="allergies"
                    rows={4}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Enter ingredients you're allergic to (comma separated)
Example: peanuts, shellfish, dairy"
                    value={allergies}
                    onChange={(e) => setAllergies(e.target.value)}
                  ></textarea>
                </div>

                <div>
                  <label htmlFor="preferences" className="block text-sm font-medium text-gray-700 mb-1">
                    Preferences
                  </label>
                  <textarea
                    id="preferences"
                    rows={4}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Enter ingredients you prefer (comma separated)
Example: chicken, rice, tomatoes"
                    value={preferences}
                    onChange={(e) => setPreferences(e.target.value)}
                  ></textarea>
                </div>
              </div>

              <div className="mt-6 flex justify-center">
                <Button
                  type="submit"
                  variant="primary"
                  className="bg-orange-500 hover:bg-orange-600 rounded-full"
                  disabled={loading || (!allergies.trim() && !preferences.trim())}
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Getting Recommendations...
                    </>
                  ) : (
                    <>
                      Get Recommendations
                      <ChevronRight className="ml-2 h-5 w-5" />
                    </>
                  )}
                </Button>
              </div>
            </form>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-lg flex items-center">
              <AlertTriangle size={20} className="mr-2" />
              <span>{error}</span>
            </div>
          )}

          {recommendations.length > 0 && (
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="bg-black text-white p-4">
                <h2 className="text-xl font-bold">Your Recommended Recipes</h2>
              </div>
              <div className="p-4">
                <div className="space-y-4">
                  {recommendations.map((recipe, index) => (
                    <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <h3 className="text-lg font-semibold text-orange-600">{recipe.name}</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        <strong>Ingredients:</strong> {recipe.ingredients}
                      </p>
                      <div className="mt-2 flex items-center">
                        <div className="text-xs text-gray-500">Match Score:</div>
                        <div className="ml-2 bg-gray-200 rounded-full h-2 w-24">
                          <div
                            className="bg-orange-500 h-2 rounded-full"
                            style={{ width: `${Math.round(recipe.score * 100)}%` }}
                          ></div>
                        </div>
                        <div className="ml-2 text-xs text-gray-500">{Math.round(recipe.score * 100)}%</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default RecipeRecommendations
