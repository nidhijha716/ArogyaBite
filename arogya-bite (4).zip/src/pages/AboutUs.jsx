import { Link } from "react-router-dom"
import { Shield, Users, Award, Zap } from "lucide-react"
import Button from "../components/Button"
import SectionHeading from "../components/SectionHeading"

const AboutUs = () => {
  return (
    <div className="min-h-screen pt-20 pb-12">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-emerald-50 to-white py-12 md:py-20">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="heading-xl mb-6">About ArogyaBite</h1>
            <p className="text-xl text-gray-600 mb-8">
              We're on a mission to make food safety accessible to everyone through innovative technology.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-12 md:py-20">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionHeading
                title="Our Story"
                subtitle="How ArogyaBite began its journey to revolutionize food safety"
              />
              <div className="space-y-4 text-gray-600">
                <p>
                  ArogyaBite was founded in 2023 by a team of food scientists, AI specialists, and health advocates who
                  shared a common concern: the rising incidence of foodborne illnesses and contamination.
                </p>
                <p>
                  Our founders recognized that while food safety technology existed in industrial settings, there was no
                  accessible solution for everyday consumers to quickly assess the safety of their food.
                </p>
                <p>
                  After two years of research and development, we created an AI-powered system that could detect various
                  forms of food contamination and health risks through image analysis, making food safety accessible to
                  everyone with a smartphone.
                </p>
                <p>
                  Today, ArogyaBite is used by thousands of people worldwide to make informed decisions about the food
                  they consume, contributing to better health outcomes and reduced food waste.
                </p>
              </div>
            </div>
            <div className="relative">
              <img src="/images/team-working.jpg" alt="Our Team" className="rounded-lg shadow-xl" />
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600">
                    <Users size={24} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-500">Founded by</p>
                    <p className="font-bold text-gray-800">Food Safety Experts</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Mission */}
      <section className="py-12 md:py-20 bg-gray-50">
        <div className="container-custom">
          <SectionHeading
            title="Our Mission"
            subtitle="We believe everyone deserves access to safe, healthy food"
            centered={true}
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-600 mb-4">
                <Shield size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Protect Health</h3>
              <p className="text-gray-600">
                We aim to reduce foodborne illnesses by providing instant detection of potential contamination and
                health risks.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-600 mb-4">
                <Award size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Empower Consumers</h3>
              <p className="text-gray-600">
                We believe in empowering people with the knowledge and tools to make informed decisions about the food
                they consume.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-600 mb-4">
                <Zap size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Innovate Technology</h3>
              <p className="text-gray-600">
                We continuously improve our AI technology to provide the most accurate and comprehensive food safety
                analysis.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-12 md:py-20">
        <div className="container-custom">
          <SectionHeading title="Meet Our Team" subtitle="The passionate experts behind ArogyaBite" centered={true} />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            {/* Team Member 1 */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <img
                src="/images/team-member-1.jpg"
                alt="Dr. Sarah Chen"
                className="w-full h-64 object-cover object-center"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Dr. Sarah Chen</h3>
                <p className="text-emerald-600 mb-2">Founder & CEO</p>
                <p className="text-sm text-gray-600">
                  Food scientist with 15+ years of experience in food safety and quality control.
                </p>
              </div>
            </div>

            {/* Team Member 2 */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <img src="/images/team-member-2.jpg" alt="Raj Patel" className="w-full h-64 object-cover object-center" />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Raj Patel</h3>
                <p className="text-emerald-600 mb-2">CTO</p>
                <p className="text-sm text-gray-600">
                  AI specialist with expertise in computer vision and machine learning.
                </p>
              </div>
            </div>

            {/* Team Member 3 */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <img
                src="/images/team-member-3.jpg"
                alt="Maria Rodriguez"
                className="w-full h-64 object-cover object-center"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold">Maria Rodriguez</h3>
                <p className="text-emerald-600 mb-2">Head of Research</p>
                <p className="text-sm text-gray-600">
                  Microbiologist specializing in foodborne pathogens and contamination detection.
                </p>
              </div>
            </div>

            {/* Team Member 4 */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <img src="/images/team-member-4.jpg" alt="David Kim" className="w-full h-64 object-cover object-center" />
              <div className="p-4">
                <h3 className="text-lg font-semibold">David Kim</h3>
                <p className="text-emerald-600 mb-2">Product Director</p>
                <p className="text-sm text-gray-600">
                  UX specialist focused on creating intuitive and accessible health technology.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-20 bg-emerald-600 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Join Us in Making Food Safer</h2>
          <p className="text-xl text-emerald-100 mb-8 max-w-3xl mx-auto">
            Try ArogyaBite today and be part of our mission to ensure everyone has access to safe, healthy food.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/upload">
              <Button variant="primary" className="bg-white text-emerald-600 hover:bg-gray-100">
                Try ArogyaBite Now
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="text-white border-white hover:bg-white hover:text-emerald-600">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default AboutUs
