import RecipeRecommendation from "../components/RecipeRecommendation"

const RecipeRecommendationPage = () => {
  return <RecipeRecommendation />
}

export default RecipeRecommendationPage
