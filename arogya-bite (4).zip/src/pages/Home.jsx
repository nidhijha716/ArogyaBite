import { Link } from "react-router-dom"
import { CuboidIcon as Cube, ChevronRight } from "lucide-react"
import Button from "../components/Button"
import FAQ from "../components/FAQ"

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-black text-white min-h-screen pt-20">
        <div className="container-custom h-full grid grid-cols-1 lg:grid-cols-2 gap-8 py-12">
          <div className="flex flex-col justify-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Discover Safe Eating <br />
              with ArogyaBite
            </h1>
            <p className="text-xl mb-8 text-gray-300">
              ArogyaBite empowers you to identify food allergens effortlessly. Upload an image of your food label and
              let our AI do the rest!
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/upload">
                <Button variant="primary" className="bg-orange-500 hover:bg-orange-600 text-white rounded-full">
                  Scan
                </Button>
              </Link>
              <Link to="/about">
                <Button variant="outline" className="text-white border-white hover:bg-white/10 rounded-full">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative">
              <img src="/images/people-looking-at-labels.jpg" alt="People using ArogyaBite" className="rounded-lg" />
              <div className="absolute bottom-0 left-0 right-0 bg-black/80 p-4">
                <h3 className="text-white font-bold">Your Safety Matters</h3>
                <p className="text-gray-300 text-sm">Stay informed about your food choices.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* OCR Technology Section */}
      <section className="bg-black text-white py-20">
        <div className="container-custom grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="mb-4">
              <Cube className="h-10 w-10 text-white" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Revolutionize Your Food Safety with Our OCR-Based Allergen Detection
            </h2>
            <p className="text-gray-300 mb-6">
              Easily upload a food label image or paste ingredient text for instant analysis. Our advanced OCR
              technology swiftly extracts the relevant information, allowing you to identify potential allergens with
              confidence.
            </p>
          </div>
          <div>
            <img src="/images/women-talking.jpg" alt="Women discussing food safety" className="rounded-lg" />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-white py-20 border border-purple-500">
        <div className="container-custom">
          <div className="text-center mb-4">
            <span className="text-gray-700 font-medium">Safe</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-6">Discover How ArogyaBite Works for You</h2>
          <p className="text-center text-gray-600 max-w-3xl mx-auto mb-16">
            ArogyaBite simplifies allergen detection with a user-friendly platform. Just upload a food label or enter
            ingredients to get started.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="flex justify-center mb-6">
                <Cube className="h-12 w-12 text-black" />
              </div>
              <h3 className="text-xl font-bold mb-4">Step 1: Upload Your Food Label</h3>
              <p className="text-gray-600">Easily upload an image or paste ingredient text.</p>
            </div>

            <div className="text-center">
              <div className="flex justify-center mb-6">
                <Cube className="h-12 w-12 text-black" />
              </div>
              <h3 className="text-xl font-bold mb-4">Step 2: Get Allergen Analysis</h3>
              <p className="text-gray-600">Our AI scans for allergens and assesses risk.</p>
            </div>

            <div className="text-center">
              <div className="flex justify-center mb-6">
                <Cube className="h-12 w-12 text-black" />
              </div>
              <h3 className="text-xl font-bold mb-4">Step 3: Review Your Risk Report</h3>
              <p className="text-gray-600">Receive a personalized report with safety recommendations.</p>
            </div>
          </div>

          <div className="flex justify-center mt-12 gap-4">
            <Link to="/upload">
              <Button variant="secondary" className="bg-gray-100 text-black rounded-full">
                Start
              </Button>
            </Link>
            <Link to="/about">
              <Button variant="text" className="text-black flex items-center">
                Learn More <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container-custom">
          <div className="text-center mb-4">
            <span className="text-gray-700 font-medium">Features</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-6">Explore Our Core Features for Safe Eating</h2>
          <p className="text-center text-gray-600 max-w-3xl mx-auto mb-16">
            ArogyaBite empowers you to make informed food choices. Discover how our innovative features can help you
            navigate allergens with confidence.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <img
                src="/images/allergen-reporting.jpg"
                alt="Allergen reporting"
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-bold text-center mb-3">Comprehensive Allergen Risk Reporting</h3>
              <p className="text-center text-gray-600">
                Receive detailed insights into potential allergens in your food.
              </p>
            </div>

            <div>
              <img
                src="/images/personalized-analysis.jpg"
                alt="Personalized analysis"
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-bold text-center mb-3">Personalized Analysis Based on Your Profile</h3>
              <p className="text-center text-gray-600">Our AI tailors risk assessments to your health needs.</p>
            </div>

            <div>
              <img
                src="/images/easy-sharing.jpg"
                alt="Easy sharing"
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-bold text-center mb-3">Easy Download and Sharing of Reports</h3>
              <p className="text-center text-gray-600">Effortlessly download or share your allergen reports.</p>
            </div>
          </div>

          <div className="flex justify-center mt-12 gap-4">
            <Link to="/about">
              <Button variant="secondary" className="bg-gray-100 text-black rounded-full">
                Learn More
              </Button>
            </Link>
            <Link to="/upload">
              <Button variant="primary" className="bg-black text-white rounded-full flex items-center">
                Sign Up <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-black text-white">
        <div className="container-custom">
          <h2 className="text-4xl font-bold text-center mb-6">FAQs</h2>
          <p className="text-center text-gray-300 max-w-3xl mx-auto mb-12">
            Find answers to your questions about ArogyaBite and how to use its features.
          </p>

          <div className="max-w-3xl mx-auto">
            <FAQ
              items={[
                {
                  question: "How does it work?",
                  answer:
                    "ArogyaBite uses advanced OCR technology to scan food labels. It analyzes the ingredient text to identify allergens based on your profile. This helps you make informed dietary choices.",
                },
                {
                  question: "Is it user-friendly?",
                  answer:
                    "ArogyaBite is designed with simplicity in mind. The intuitive interface allows users to easily upload images or enter text, making allergen detection straightforward.",
                },
                {
                  question: "What is a risk report?",
                  answer:
                    "A risk report summarizes the allergens detected in your food. It provides a visual risk level and personalized recommendations. This empowers you to choose safe food options.",
                },
                {
                  question: "Can I share reports?",
                  answer:
                    "Yes, you can easily download or share your risk reports. This feature allows you to keep track of allergens and share information with friends or family. Stay informed and safe together!",
                },
                {
                  question: "What if I have questions?",
                  answer:
                    "Our support team is here to help! If you have any questions or need assistance, don't hesitate to reach out. We're committed to ensuring your experience is seamless.",
                },
              ]}
            />
          </div>

          <div className="text-center mt-16">
            <h3 className="text-2xl font-bold mb-4">Still have questions?</h3>
            <p className="text-gray-300 mb-8">We're here to help you with any inquiries.</p>
            <Link to="/contact">
              <Button variant="primary" className="bg-orange-500 hover:bg-orange-600 text-white rounded-full">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home
