"use client"

import { useState, useEffect } from "react"
import { useParams, Link } from "react-router-dom"
import { ShieldCheck, AlertTriangle, Info, ArrowLeft, Download, Share2 } from "lucide-react"
import Button from "../components/Button"
import Loader from "../components/Loader"

const RiskReport = () => {
  const { id } = useParams()
  const [report, setReport] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    // Simulate API call to fetch report data
    const fetchReport = async () => {
      setLoading(true)

      try {
        // Simulate API delay
        await new Promise((resolve) => setTimeout(resolve, 1500))

        // Mock report data
        const mockReport = {
          id: id,
          timestamp: new Date().toISOString(),
          foodName: "Mixed Vegetable Salad",
          overallRisk: "medium",
          riskScore: 45,
          allergens: [
            {
              name: "Peanuts",
              risk: "high",
              description: "Detected in ingredients list",
              recommendation: "Avoid if allergic to peanuts",
            },
            {
              name: "Gluten",
              risk: "medium",
              description: "May contain traces",
              recommendation: "Caution advised for celiac disease",
            },
            {
              name: "Soy",
              risk: "low",
              description: "Present in small amounts",
              recommendation: "Generally safe for mild soy sensitivity",
            },
          ],
          recommendations: [
            "Not recommended for individuals with peanut allergies",
            "Exercise caution if you have celiac disease or gluten sensitivity",
            "Safe for individuals without the listed allergen concerns",
          ],
        }

        setReport(mockReport)
        setLoading(false)

        // Actual API call would look like this:
        /*
        const response = await fetch(`https://api.arogyabite.com/reports/${id}`);
        if (!response.ok) {
          throw new Error('Failed to fetch report');
        }
        const data = await response.json();
        setReport(data);
        setLoading(false);
        */
      } catch (err) {
        setError("Failed to load report. Please try again.")
        setLoading(false)
      }
    }

    fetchReport()
  }, [id])

  // Risk level badge component
  const RiskBadge = ({ level }) => {
    const badges = {
      low: {
        bg: "bg-green-100",
        text: "text-green-800",
        icon: <ShieldCheck className="w-4 h-4 mr-1" />,
        label: "Low Risk",
      },
      medium: {
        bg: "bg-yellow-100",
        text: "text-yellow-800",
        icon: <AlertTriangle className="w-4 h-4 mr-1" />,
        label: "Medium Risk",
      },
      high: {
        bg: "bg-red-100",
        text: "text-red-800",
        icon: <AlertTriangle className="w-4 h-4 mr-1" />,
        label: "High Risk",
      },
    }

    const badge = badges[level] || badges.low

    return (
      <span
        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium ${badge.bg} ${badge.text}`}
      >
        {badge.icon}
        {badge.label}
      </span>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <Loader size="large" color="orange" />
          <p className="mt-4 text-gray-600">Analyzing allergens in your food...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center max-w-md p-6 bg-white rounded-lg shadow-md">
          <AlertTriangle size={48} className="mx-auto text-red-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Error Loading Report</h2>
          <p className="text-gray-600 mb-6">{error}</p>
          <Link to="/upload">
            <Button variant="primary" className="bg-orange-500 hover:bg-orange-600 rounded-full">
              Try Again
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  if (!report) {
    return null
  }

  return (
    <div className="min-h-screen pt-20 pb-12 bg-gray-50">
      <div className="container-custom">
        <div className="mb-6 flex items-center">
          <Link to="/upload" className="text-gray-600 hover:text-orange-500 transition-colors flex items-center">
            <ArrowLeft size={20} className="mr-2" />
            Back to Scanner
          </Link>
        </div>

        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          {/* Report Header */}
          <div className="bg-black text-white p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold mb-2">Allergen Risk Report</h1>
                <p className="text-gray-300">
                  Report ID: {report.id} • {new Date(report.timestamp).toLocaleString()}
                </p>
              </div>
              <div className="mt-4 md:mt-0 flex space-x-3">
                <Button variant="outline" className="text-white border-white hover:bg-white/10 rounded-full">
                  <Download size={18} className="mr-2" />
                  Download
                </Button>
                <Button variant="outline" className="text-white border-white hover:bg-white/10 rounded-full">
                  <Share2 size={18} className="mr-2" />
                  Share
                </Button>
              </div>
            </div>
          </div>

          {/* Report Content */}
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-4">{report.foodName}</h2>
              <div className="flex items-center">
                <span className="mr-3">Overall Risk:</span>
                <RiskBadge level={report.overallRisk} />
              </div>
            </div>

            {/* Risk Score */}
            <div className="mb-6 bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700 font-medium">Risk Score:</span>
                <span className="font-bold">{report.riskScore}/100</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className={`h-2.5 rounded-full ${
                    report.riskScore < 30 ? "bg-green-500" : report.riskScore < 70 ? "bg-yellow-500" : "bg-red-500"
                  }`}
                  style={{ width: `${report.riskScore}%` }}
                ></div>
              </div>
            </div>

            {/* Allergens */}
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-4">Detected Allergens</h2>
              <div className="space-y-4">
                {report.allergens.map((allergen, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{allergen.name}</h3>
                      <RiskBadge level={allergen.risk} />
                    </div>
                    <p className="text-gray-700 mb-2">{allergen.description}</p>
                    <p className="text-sm text-gray-600 italic">{allergen.recommendation}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            <div className="mt-8 pt-6 border-t border-gray-200">
              <div className="flex items-center mb-4">
                <Info size={20} className="text-orange-500 mr-2" />
                <h2 className="text-xl font-semibold">Recommendations</h2>
              </div>
              <ul className="space-y-2">
                {report.recommendations.map((recommendation, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-orange-500 mr-2">•</span>
                    <span>{recommendation}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Disclaimer */}
            <div className="mt-8 pt-4 border-t border-gray-200 text-sm text-gray-500">
              <p>
                <strong>Disclaimer:</strong> This report is generated by AI and should be used as a guide only.
                ArogyaBite does not guarantee 100% accuracy. Always use your judgment and consult with health
                professionals if you have concerns about food allergies.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default RiskReport
