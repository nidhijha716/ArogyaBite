"use client"

import { useState, useRef } from "react"
import { useNavigate } from "react-router-dom"
import { Upload, Camera, X, AlertTriangle, FileText } from "lucide-react"
import Button from "../components/Button"
import Loader from "../components/Loader"
import SectionHeading from "../components/SectionHeading"

const UploadImage = () => {
  const [image, setImage] = useState(null)
  const [preview, setPreview] = useState(null)
  const [dragActive, setDragActive] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)
  const [textInput, setTextInput] = useState("")
  const [inputMethod, setInputMethod] = useState("image") // "image" or "text"
  const fileInputRef = useRef(null)
  const navigate = useNavigate()

  // Handle file selection
  const handleFile = (file) => {
    setError(null)

    // Check if file is an image
    if (!file.type.match("image.*")) {
      setError("Please upload an image file (JPEG, PNG, etc.)")
      return
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError("Image size should be less than 5MB")
      return
    }

    setImage(file)

    // Create preview
    const reader = new FileReader()
    reader.onload = (e) => setPreview(e.target.result)
    reader.readAsDataURL(file)
  }

  // Handle file input change
  const handleChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  // Handle button click to trigger file input
  const handleButtonClick = () => {
    fileInputRef.current.click()
  }

  // Handle drag events
  const handleDrag = (e) => {
    e.preventDefault()
    e.stopPropagation()

    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  // Handle drop event
  const handleDrop = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }

  // Handle text input change
  const handleTextInputChange = (e) => {
    setTextInput(e.target.value)
    setError(null)
  }

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault()

    if (inputMethod === "image" && !image) {
      setError("Please select an image to scan")
      return
    }

    if (inputMethod === "text" && !textInput.trim()) {
      setError("Please enter ingredient text to analyze")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      // Simulate API call (replace with actual API endpoint)
      setTimeout(() => {
        // Simulate successful response
        setIsLoading(false)
        // Navigate to report page with a mock ID
        navigate("/report/123")
      }, 2000)

      // Actual API call would look like this:
      /*
      if (inputMethod === "image") {
        const formData = new FormData()
        formData.append("image", image)
        
        const response = await fetch('https://api.arogyabite.com/scan/image', {
          method: 'POST',
          body: formData,
        });
      } else {
        const response = await fetch('https://api.arogyabite.com/scan/text', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ text: textInput }),
        });
      }
      
      if (!response.ok) {
        throw new Error('Failed to analyze');
      }
      
      const data = await response.json();
      setIsLoading(false);
      navigate(`/report/${data.reportId}`);
      */
    } catch (err) {
      setIsLoading(false)
      setError(err.message || "Something went wrong. Please try again.")
    }
  }

  // Clear selected image
  const clearImage = () => {
    setImage(null)
    setPreview(null)
  }

  return (
    <div className="min-h-screen pt-20 pb-12 bg-gray-50">
      <div className="container-custom">
        <SectionHeading
          title="Scan Your Food Label"
          subtitle="Upload a photo of your food label or paste ingredient text to detect allergens"
          centered={true}
        />

        <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-md p-6 md:p-8">
          {/* Toggle between image and text input */}
          <div className="flex mb-6 border-b border-gray-200">
            <button
              className={`py-3 px-4 font-medium ${
                inputMethod === "image"
                  ? "text-orange-500 border-b-2 border-orange-500"
                  : "text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => setInputMethod("image")}
            >
              <Camera className="inline-block mr-2 h-5 w-5" />
              Upload Image
            </button>
            <button
              className={`py-3 px-4 font-medium ${
                inputMethod === "text"
                  ? "text-orange-500 border-b-2 border-orange-500"
                  : "text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => setInputMethod("text")}
            >
              <FileText className="inline-block mr-2 h-5 w-5" />
              Paste Text
            </button>
          </div>

          <form onSubmit={handleSubmit}>
            {/* Image Upload Area */}
            {inputMethod === "image" && (
              <>
                {!preview ? (
                  <div
                    className={`border-2 border-dashed rounded-lg p-8 text-center ${
                      dragActive ? "border-orange-500 bg-orange-50" : "border-gray-300"
                    }`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                  >
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center text-orange-500">
                        <Upload size={32} />
                      </div>
                      <div>
                        <p className="text-lg font-medium">Drag and drop your food label image here</p>
                        <p className="text-gray-500 mt-1">or click to browse files</p>
                      </div>
                      <p className="text-sm text-gray-500">
                        Supported formats: JPEG, PNG, WebP <br />
                        Maximum file size: 5MB
                      </p>
                      <input
                        type="file"
                        ref={fileInputRef}
                        id="file-upload"
                        className="hidden"
                        accept="image/*"
                        onChange={handleChange}
                      />
                      <Button
                        type="button"
                        variant="primary"
                        className="bg-orange-500 hover:bg-orange-600 rounded-full"
                        onClick={handleButtonClick}
                      >
                        Select Image
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="relative">
                    <img
                      src={preview || "/placeholder.svg"}
                      alt="Food label preview"
                      className="w-full h-auto rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={clearImage}
                      className="absolute top-2 right-2 bg-gray-800 bg-opacity-70 text-white p-2 rounded-full hover:bg-opacity-90 transition-all"
                    >
                      <X size={20} />
                    </button>
                  </div>
                )}
              </>
            )}

            {/* Text Input Area */}
            {inputMethod === "text" && (
              <div className="space-y-4">
                <label htmlFor="ingredient-text" className="block text-sm font-medium text-gray-700">
                  Paste ingredient list from food label
                </label>
                <textarea
                  id="ingredient-text"
                  rows={8}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Example: Water, Sugar, Wheat Flour, Milk, Eggs, Peanuts, Soy Lecithin..."
                  value={textInput}
                  onChange={handleTextInputChange}
                ></textarea>
                <p className="text-sm text-gray-500">
                  For best results, copy the entire ingredient list exactly as it appears on the packaging.
                </p>
              </div>
            )}

            {/* Error Message */}
            {error && (
              <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-lg flex items-center">
                <AlertTriangle size={20} className="mr-2" />
                <span>{error}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="mt-6 flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                type="submit"
                variant="primary"
                className="w-full sm:w-auto bg-orange-500 hover:bg-orange-600 rounded-full"
                disabled={
                  isLoading || (inputMethod === "image" && !image) || (inputMethod === "text" && !textInput.trim())
                }
              >
                {isLoading ? (
                  <>
                    <Loader size="small" color="white" />
                    <span className="ml-2">Analyzing...</span>
                  </>
                ) : (
                  <>
                    <Camera className="mr-2 h-5 w-5" />
                    Detect Allergens
                  </>
                )}
              </Button>

              <Button
                type="button"
                variant="secondary"
                className="w-full sm:w-auto rounded-full"
                onClick={() => navigate("/")}
              >
                Back to Home
              </Button>
            </div>
          </form>

          {/* Instructions */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <h3 className="text-lg font-semibold mb-3">How to get the best results:</h3>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                Take a clear, well-lit photo of the ingredient list
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                Ensure the text is readable and not blurry
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                Include the entire ingredient list for comprehensive analysis
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                For packaged foods, capture any allergen warnings or statements
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default UploadImage
