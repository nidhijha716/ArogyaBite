import { Loader2 } from "lucide-react"

export default function Loading() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900">
      <div className="text-center">
        <Loader2 className="h-12 w-12 animate-spin text-green-500 mx-auto" />
        <h2 className="mt-4 text-xl font-semibold">Loading Recipe Recommendation System...</h2>
        <p className="mt-2 text-gray-400">Please wait while we prepare your culinary experience</p>
      </div>
    </div>
  )
}
