import RecipeRecommendationSystem from "@/components/RecipeRecommendationSystem"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-900 text-white p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <RecipeRecommendationSystem />
      </div>
    </main>
  )
}
