import { NextResponse } from "next/server"
import { spawn } from "child_process"
import path from "path"
import fs from "fs"

// Helper function to run Python script
async function runPythonScript(allergies: string[], preferences: string[]) {
  return new Promise((resolve, reject) => {
    // Path to the Python script
    const scriptPath = path.join(process.cwd(), "python", "recommend_api.py")

    // Check if the script exists
    if (!fs.existsSync(scriptPath)) {
      reject(new Error(`Python script not found at ${scriptPath}`))
      return
    }

    // Spawn Python process
    const pythonProcess = spawn("python", [scriptPath, JSON.stringify(allergies), JSON.stringify(preferences)])

    let result = ""
    let errorOutput = ""

    // Collect data from script
    pythonProcess.stdout.on("data", (data) => {
      result += data.toString()
    })

    pythonProcess.stderr.on("data", (data) => {
      errorOutput += data.toString()
    })

    // Handle process completion
    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`Python script exited with code ${code}: ${errorOutput}`))
        return
      }

      try {
        const parsedResult = JSON.parse(result)
        resolve(parsedResult)
      } catch (error) {
        reject(new Error(`Failed to parse Python script output: ${result}`))
      }
    })
  })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { allergies = [], preferences = [] } = body

    // Validate input
    if (!preferences.length) {
      return NextResponse.json({ error: "Please provide at least one preferred ingredient" }, { status: 400 })
    }

    // Run Python script
    const recommendations = await runPythonScript(allergies, preferences)

    return NextResponse.json({ recommendations })
  } catch (error) {
    console.error("Error in recommendation API:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 },
    )
  }
}
