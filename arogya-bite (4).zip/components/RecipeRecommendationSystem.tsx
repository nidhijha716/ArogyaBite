"use client"

import type React from "react"

import { useState } from "react"
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react"
import Image from "next/image"

type Recipe = {
  id: number
  name: string
  ingredients: string
  similarity_score: number
}

export default function RecipeRecommendationSystem() {
  const [allergies, setAllergies] = useState("")
  const [preferences, setPreferences] = useState("")
  const [recommendations, setRecommendations] = useState<Recipe[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/recommend", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          allergies: allergies
            .split(",")
            .map((item) => item.trim())
            .filter(Boolean),
          preferences: preferences
            .split(",")
            .map((item) => item.trim())
            .filter(Boolean),
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to get recommendations")
      }

      const data = await response.json()
      setRecommendations(data.recommendations)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="rounded-lg overflow-hidden">
      <div className="flex items-center gap-3 mb-6">
        <Image src="/food-icon.png" alt="Food icon" width={48} height={48} className="rounded-full" />
        <div>
          <h1 className="text-2xl font-bold">Smart Recipe Recommendation System</h1>
          <p className="text-gray-400">Get top recipes based on your preferences and allergies!</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="h-5 w-5 text-red-500" />
            <label htmlFor="allergies" className="block">
              Ingredients you&apos;re allergic to (comma separated):
            </label>
          </div>
          <input
            id="allergies"
            type="text"
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-md text-white"
            value={allergies}
            onChange={(e) => setAllergies(e.target.value)}
            placeholder="e.g., peanuts, shellfish, dairy"
          />
        </div>

        <div>
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <label htmlFor="preferences" className="block">
              Ingredients you prefer (comma separated):
            </label>
          </div>
          <input
            id="preferences"
            type="text"
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-md text-white"
            value={preferences}
            onChange={(e) => setPreferences(e.target.value)}
            placeholder="e.g., chicken, rice, tomatoes"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-4 rounded-md transition-colors"
          disabled={loading}
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin" />
              Getting Recommendations...
            </span>
          ) : (
            "Get Recommendations"
          )}
        </button>
      </form>

      {error && (
        <div className="mt-6 p-4 bg-red-900/50 border border-red-700 rounded-md text-red-200">
          <p className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            {error}
          </p>
        </div>
      )}

      {recommendations.length > 0 && (
        <div className="mt-6">
          <div className="bg-green-900/30 border border-green-800 rounded-md p-4 mb-4">
            <h2 className="text-lg font-medium">Here are your top recipe recommendations:</h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="text-left border-b border-gray-700">
                  <th className="py-2 px-4">Name</th>
                  <th className="py-2 px-4">Ingredients_name</th>
                  <th className="py-2 px-4 text-right">similarity_score</th>
                </tr>
              </thead>
              <tbody>
                {recommendations.map((recipe, index) => (
                  <tr key={index} className="border-b border-gray-800 hover:bg-gray-800/50">
                    <td className="py-3 px-4">{recipe.name}</td>
                    <td className="py-3 px-4 text-gray-400">{recipe.ingredients}</td>
                    <td className="py-3 px-4 text-right font-mono">{recipe.similarity_score.toFixed(4)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
